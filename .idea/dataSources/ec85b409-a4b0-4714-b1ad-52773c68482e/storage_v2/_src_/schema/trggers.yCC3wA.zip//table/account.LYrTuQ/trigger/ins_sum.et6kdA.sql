CREATE TRIGGER ins_sum
  BEFORE INSERT
  ON account
  FOR EACH ROW
  SET @sum = @sum + NEW.amount;

